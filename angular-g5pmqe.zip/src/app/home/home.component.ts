import { Component, OnInit } from '@angular/core';
import { WeatherServiceService } from '../weather-service.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers: [WeatherServiceService]
})
export class HomeComponent implements OnInit {

  constructor(private weatherService:WeatherServiceService, private router: Router) { }
  name:any;
  formError:any;
  showError:boolean = false;
  ngOnInit() {
    console.log(this.name)
  }
  getWeather(){
    this.showError = false;
    var regex = /^[a-z A-Z]$/;
    if (this.name === undefined) {
      this.showError = true;
      this.formError = 'The city name is mandatory to proceed further'
    }else if (regex.test(this.name)) {
      this.showError = true;
      this.formError = 'The city name cannot contain special characters'
    } else {
    let formData = new FormData();
    formData.append('c1', this.name);
    formData.append('action','gpcm');
    formData.append('cp','');
    this.weatherService.getLatLong(formData).subscribe((response) => {
    localStorage.setItem('latitude', '12.971599' );
    localStorage.setItem('longditude', '77.594566');
    this.router.navigateByUrl('/weather');
  });
    }
    
  }
}