import { Injectable } from '@angular/core';
import {Http, Response} from '@angular/http';
import {Observable} from 'rxjs';
import 'rxjs/Rx';

@Injectable()
export class WeatherServiceService {

  constructor(private http: Http) { }

  getLatLong(reqBody:any):Observable<any> {
    const url = "https://www.latlong.net/_spm4.php";
   return this.http.post(url, reqBody)
   .map(res=> res);
  }


  getForecast(lat, long):Observable<any> {
    const url = "https://api.darksky.net/forecast/dd3e191547484d14a57648175572d88e/"+lat+","+long;
    return this.http.get(url).map( res => res.json());
  }

}